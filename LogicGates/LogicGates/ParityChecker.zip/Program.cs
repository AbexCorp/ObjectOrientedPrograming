﻿using System;

namespace LogicGate
{
    class Program
    {
        static void Main()
        {
            TestParityChecker();
        }

        public static void TestParityChecker()
        {
            string[] tests =
            {
                "00000",
                "00001",
                "00010",
                "00011",
                "00100",
                "00101",
                "00110",
                "00111",
                "01000",
                "01001",
                "01010",
                "01011",
                "01100",
                "01101",
                "01110",
                "01111",
                "10000",
                "10001",
                "10010",
                "10011",
                "10100",
                "10101",
                "10110",
                "10111",
                "11000",
                "11001",
                "11010",
                "11011",
                "11100",
                "11101",
                "11110",
                "11111"
            };
            char[] expectedOutputs =
            {
                '0',
                '1',
                '1',
                '0',
                '1',
                '0',
                '0',
                '1',
                '1',
                '0',
                '0',
                '1',
                '0',
                '1',
                '1',
                '0',
                '1',
                '0',
                '0',
                '1',
                '0',
                '1',
                '1',
                '0',
                '0',
                '1',
                '1',
                '0',
                '1',
                '0',
                '0',
                '1'
            };

            for(int i = 0; i < 32; i++)
            {
                bool exO = expectedOutputs[i] == '1';
                if (exO == ParityChecker(tests[i]))
                    Console.WriteLine("Pass");
                else
                    Console.WriteLine($"Expected: {exO}, got: {ParityChecker(tests[i])}, input {tests[i]}");
            }
        }

        public static bool ParityChecker(string input)
        {
            bool i1 = input[0] == '1';
            bool i2 = input[1] == '1';
            bool i3 = input[2] == '1';
            bool i4 = input[3] == '1';
            bool p = input[4] == '1';

            i1 ^= i2;
            i3 ^= i4;

            i1 ^= i3;

            return i1 ^ p;
        }
    }
}